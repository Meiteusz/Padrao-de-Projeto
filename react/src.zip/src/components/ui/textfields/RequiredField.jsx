import { Tooltip } from "@mui/material";

function RequiredField() {
  return (
    <>
      <Tooltip title="Campo obrigatório">
        <span
          style={{
            marginLeft: "5%",
            color: "red",
            fontWeight: "bold",
            cursor: "default",
          }}
        >
          *
        </span>
      </Tooltip>
    </>
  );
}

export default RequiredField;
