import CurrencyInput from "react-currency-input-field";

import RequiredField from "../RequiredField";

function CurrencyField(props) {
  return (
    <div>
      <label style={{ marginBottom: "2%", fontWeight: "bold" }}>
        {props.label}
      </label>
      {props.required && <RequiredField />}
      <CurrencyInput
        className="form-control"
        name={props.name}
        decimalsLimit={2}
        onValueChange={props.onChange}
        value={props.value}
        prefix="R$ "
        style={{
          width: "200px",
          borderColor: props.error && "red",
          fontSize: "15px",
          borderRadius: "5px",
        }}
      />
    </div>
  );
}

export default CurrencyField;
