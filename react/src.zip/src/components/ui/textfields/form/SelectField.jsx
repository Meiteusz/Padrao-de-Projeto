import { Dropdown } from "primereact/dropdown";

import RequiredField from "../RequiredField";

import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "./styles.css";

function SelectWithFilter(props) {
  return (
    <div>
      <label style={{ marginBottom: "2%", fontWeight: "bold" }}>
        {props.label}
      </label>
      {props.required && <RequiredField />}
      <br />
      <Dropdown
        name={props.name}
        value={props.value}
        onChange={props.onChange}
        options={props.options}
        placeholder={"Selecione uma opção" ?? props.placeholder}
        filter
        className="small-dropdown"
        style={{
          width: "300px",
          height: "35px",
          fontSize: "13px",
          lineHeight: "5px",
          borderColor: props.error && "red",
        }}
      />
      <br />
      {props.error && <span style={{ color: "red" }}>{props.error}</span>}
    </div>
  );
}

export { SelectWithFilter };
