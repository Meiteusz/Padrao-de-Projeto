import RequiredField from "../RequiredField";

import "./styles.css";

function TextField(props) {
  return (
    <div>
      <label style={{ marginBottom: "2%", fontWeight: "bold" }}>
        {props.label}
      </label>
      {props.required && <RequiredField />}
      <br />
      <input
        type={props.type ?? "text"}
        className="form-control classic"
        style={{
          borderColor: props.error && "red",
        }}
        value={props.value}
        disabled={props.disabled}
        onChange={props.onChange}
        onBlur={props.onBlur}
        onKeyDown={props.onKeyPress}
      />
      {props.error && <span style={{ color: "red" }}>{props.error}</span>}
    </div>
  );
}

export default TextField;
