import "./styles.css";

function ButtonGroup({ children }) {
  return <div className="button-group">{children}</div>;
}

export default ButtonGroup;
