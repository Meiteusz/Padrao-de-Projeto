const TypeOptions = {

    ViewModal: "view",
    EditModal: "edit"
};

export default TypeOptions;