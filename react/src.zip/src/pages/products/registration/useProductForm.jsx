import { useState } from "react";

function useProductForm() {
  const [name, setName] = useState("");
  const [unitPrice, setUnitPrice] = useState(0);
  const [color, setColor] = useState("");
  const [unitOfMeansurement, setUnitOfMeansurement] = useState(null);
  const [type, setType] = useState(null);
  const [brandId, setBrandId] = useState(null);
  const [description, setDescription] = useState("");

  const [nameError, setNameError] = useState("");

  const nameChange = (value) => {
    setName(value);
    if (value.length < 5) {
      setNameError("O nome deve ter mais de 5 letras.");
    } else {
      setNameError(null);
    }
  };

  const unitPriceChange = (value) => {
    setUnitPrice(value);
  };

  const colorChange = (value) => {
    setColor(value);
  };

  const unitOfMeansurementChange = (value) => {
    setUnitOfMeansurement(value);
  };

  const typeChange = (value) => {
    setType(value);
  };

  const brandIdChange = (value) => {
    setBrandId(value);
  };

  const descriptionChange = (value) => {
    setDescription(value);
  };

  const getData = () => {
    return {
      name: name,
      unitPrice: unitPrice,
      color: color,
      unitOfMeansurement: unitOfMeansurement.id,
      type: type.id,
      brandId: brandId.id,
      description: description,
    };
  };

  return [
    getData,
    name,
    nameChange,
    unitPrice,
    unitPriceChange,
    color,
    colorChange,
    unitOfMeansurement,
    unitOfMeansurementChange,
    type,
    typeChange,
    brandId,
    brandIdChange,
    description,
    descriptionChange,
    nameError,
  ];
}

export default useProductForm;
