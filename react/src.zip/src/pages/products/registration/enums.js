// Arquite temporário

const unitOfMeansurement = [
    'Meter',
    'Liter',
    'Kilo',
    'Gram',
    'Unit'
];

  const productTypes = [
    'Comida',
    'Roupas',
    'Eletronicos',
    'Livros'
];

  const productColors = [
    'Amarelo',
    'Vermelho',
    'Roxo',
    'Azul',
    'Verde',
    'Branco',
    'Preto'
];

export { unitOfMeansurement, productTypes, productColors };

