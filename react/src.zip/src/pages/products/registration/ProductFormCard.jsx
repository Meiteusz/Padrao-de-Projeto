import { MDBCol } from "mdb-react-ui-kit";

import ContentPage from "../../../layouts/content/ContentPage";
import RegisterPanel from "../../../layouts/panel/register-panel/RegisterPanel";
import ButtonGroup from "../../../components/ui/buttons/group/ButtonGroup";
import useProductForm from "./useProductForm";
import TextField from "../../../components/ui/textfields/form/TextField";
import TextArea from "../../../components/ui/textfields/form/TextArea";
import CurrencyField from "../../../components/ui/textfields/form/CurrencyField";
import useAlertScheme from "../../../hooks/useAlertScheme";
import { SelectWithFilter } from "../../../components/ui/textfields/form/SelectField";
import { SaveButton } from "../../../components/ui/buttons/icons/IconButton";
import { useAlert } from "react-alert";

const cities = [
  { id: 1, label: "New York" },
  { id: 2, label: "Rome" },
  { id: 3, label: "London" },
];

function ProductFormCard() {
  const [
    getData,
    name,
    nameChange,
    unitPrice,
    unitPriceChange,
    color,
    colorChange,
    unitOfMeansurement,
    unitOfMeansurementChange,
    type,
    typeChange,
    brandId,
    brandIdChange,
    description,
    descriptionChange,
    nameError,
  ] = useProductForm();

  const [showAlert, openAlert] = useAlertScheme();
  const alert = useAlert();

  const RegisterProduct = async () => {
    try {
      if (!name) {
        openAlert(
          "error",
          "Verifique as mensagens dos campos",
          "dasihdahisdhiahisdihas"
        );
      }

      console.log(getData());
    } catch (err) {
      console.log(err);
    }
  };

  const pageConfig = {
    title: "Cadastro de Produto",
    buttons: (
      <ButtonGroup>
        <SaveButton title="Salvar produto" onClick={RegisterProduct} />
      </ButtonGroup>
    ),
  };

  return (
    <div>
      <ContentPage {...pageConfig}>
        <RegisterPanel title="Informações básicas" alertPanel={showAlert}>
          <MDBCol>
            <TextField
              required
              label="Nome do produto"
              value={name}
              onChange={(e) => nameChange(e.target.value)}
              error={nameError}
            />
          </MDBCol>
          <MDBCol>
            <CurrencyField
              required
              label="Preço unitário"
              value={unitPrice}
              onChange={(value) => unitPriceChange(value)}
            />
          </MDBCol>
          <MDBCol>
            <TextField
              required
              label="Cor"
              value={color}
              onChange={(e) => colorChange(e.target.value)}
            />
          </MDBCol>
          <MDBCol>
            <SelectWithFilter
              required
              label="Unidade de peso"
              options={cities}
              value={unitOfMeansurement}
              onChange={(e) => unitOfMeansurementChange(e.target.value)}
            />
          </MDBCol>
          <MDBCol>
            <SelectWithFilter
              required
              label="Tipo"
              options={cities}
              value={type}
              onChange={(e) => typeChange(e.target.value)}
            />
          </MDBCol>
          <MDBCol>
            <SelectWithFilter
              label="Marca"
              options={cities}
              value={brandId}
              onChange={(e) => brandIdChange(e.target.value)}
            />
          </MDBCol>
          <MDBCol>
            <TextArea
              name="description"
              label="Descrição"
              value={description}
              onChange={(e) => descriptionChange(e.target.value)}
            />
          </MDBCol>
        </RegisterPanel>
      </ContentPage>
    </div>
  );
}

export default ProductFormCard;
