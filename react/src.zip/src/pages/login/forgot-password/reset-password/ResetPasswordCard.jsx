import { useState } from "react";
import { Navigate } from "react-router-dom";
import { Box } from "@mui/material";
import { Typography } from "@mui/material";

import TextField from "../../../../components/ui/textfields/form/TextField";
import Button from "../../../../components/ui/buttons/classic/Button";
import { COLORS } from "../../../../themes/colors";

export default function ResetPasswordCard() {
  //const [passwordRequest, setPasswordRequest] = useState("");
  //const [RepeatPasswordRequest, setRepeatPasswordRequest] = useState("");
  //const [goToLogin, setgoToLogin] = useState(false);
  //
  //if (goToLogin){
  //  return <Navigate to="/signin" />
  //}
  //
  //const ResetPassword = () => {
  //
  //  const data = {
  //    AccountId: window.location.pathname.substring(15), // Melhorar
  //    NewPassword: passwordRequest
  //  }
  //};
  //
  //return(
  //    <Box style={{ width: "600px", height: "400px" }}>
  //        <Box paddingTop="40px">
  //            <Typography variant="h4" color={COLORS.PrimaryColor} textAlign="center" padd
  //                               paddingTop="35" text="Alteração de Senha" />
  //        </Box>
  //        <Box textAlign="center" paddingTop="30px">
  //            <Box>
  //                <TextField variant="standard" label="Informe sua nova senha" width="300px" onChange={(value)=> setPasswordRequest(value.target.value) } />
  //            </Box>
  //            <Box paddingTop="30px">
  //                <TextField variant="standard" label="Informe sua nova senha novamente" width="300px"
  //                                   onChange={(value)=> setRepeatPasswordRequest(value.target.value) } />
  //            </Box>
  //            <Box textAlign="center" paddingTop="30px">
  //                <DefaultButton onClick={ResetPassword} backgroundColor={COLORS.PrimaryColor} title="Confirmar" />
  //            </Box>
  //        </Box>
  //    </Box>
  //);
}
