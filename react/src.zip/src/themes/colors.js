export const COLORS = {
    PrimaryColor: '#0E6BA8',
    SecondColor: '#041A42',
    DetailsColor: '#F2F2F2',

    //#111111

    //#6C757D

    //#FFFFFF

    //#9A51E0

    //#CC92FF

    //#2A2C35  < mt bom

    //#FBFBFB

    //#009EF7

    //#F63644
}

export const BACKGROUNDS = {
    WhiteTheme: '#EDEDED',
    BlackTheme: '#052331'
}