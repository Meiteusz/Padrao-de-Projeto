﻿namespace EmailSender.API.Enums
{
    public enum eEventType
    {
        Building,
        Sending
    }
}