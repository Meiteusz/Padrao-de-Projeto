﻿namespace EmailSender.API.DTOs
{
    public class EmailAuthenticateInfoDto
    {
        public string EmailAuth { get; set; }
        public string PasswordAuth { get; set; }
    }
}