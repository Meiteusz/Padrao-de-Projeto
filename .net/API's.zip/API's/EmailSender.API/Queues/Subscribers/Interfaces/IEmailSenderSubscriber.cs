﻿namespace EmailSender.API.Queues.Subscribers.Interfaces
{
    public interface IEmailSenderSubscriber : ISubscriberBase
    {
    }
}