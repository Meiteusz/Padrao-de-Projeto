﻿namespace Dispo.APIs.ResponseBuilder
{
    public enum AlertType
    {
        Warning,
        Info,
        Success,
        Error
    }
}