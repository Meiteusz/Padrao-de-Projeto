﻿namespace Dispo.Service.Services.Interfaces
{
    public interface IMovementService
    {
    }
}