﻿using Dispo.Service.Services.Interfaces;

namespace Dispo.Service.Services
{
    public class LocationService : ILocationService
    {
    }
}