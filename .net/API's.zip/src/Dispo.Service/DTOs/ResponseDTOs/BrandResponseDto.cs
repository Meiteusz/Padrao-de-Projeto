﻿namespace Dispo.Service.DTOs.ResponseDTOs
{
    public class BrandResponseDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public byte[] Logo { get; set; }
    }
}