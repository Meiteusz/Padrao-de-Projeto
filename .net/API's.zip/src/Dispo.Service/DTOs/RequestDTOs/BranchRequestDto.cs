﻿namespace Dispo.Service.DTOs.RequestDTOs
{
    public class BranchRequestDto
    {
        public string Name { get; set; }
        public string Cnpj { get; set; }
        public long LocationId { get; set; }
    }
}