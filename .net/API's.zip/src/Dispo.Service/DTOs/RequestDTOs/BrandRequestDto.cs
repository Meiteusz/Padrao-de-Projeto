﻿namespace Dispo.Service.DTOs.RequestDTOs
{
    public class BrandRequestDto
    {
        public string Name { get; set; }
        //public byte[] Logo { get; set; }
    }
}