﻿namespace Dispo.Service.DTOs.RequestDTOs
{
    public class SignUpRequestDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CpfCnpj { get; set; }
        public string Phone { get; set; }
        public DateTime BirthDate { get; set; }
        public long BranchId { get; set; }
    }
}