﻿namespace Dispo.Service.DTOs.RequestDTOs
{
    public class ProviderRequestDto
    {
        public string Name { get; set; }
        public string Cnpj { get; set; }
    }
}