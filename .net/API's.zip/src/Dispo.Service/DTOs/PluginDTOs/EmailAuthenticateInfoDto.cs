﻿namespace Dispo.Service.DTOs.PluginDTOs
{
    public class EmailAuthenticateInfoDto
    {
        public string EmailAuth { get; set; }
        public string PasswordAuth { get; set; }
    }
}