﻿namespace Dispo.Service.DTOs.PluginDTOs.ResponseDTOs
{
    public class EmailSenderResponseDto
    {
        public string Email { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
    }
}