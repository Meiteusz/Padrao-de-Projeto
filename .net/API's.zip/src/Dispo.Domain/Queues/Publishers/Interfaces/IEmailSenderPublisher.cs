﻿namespace Dispo.Domain.Queues.Publishers.Interfaces
{
    public interface IEmailSenderPublisher : IPublisherBase
    {
    }
}