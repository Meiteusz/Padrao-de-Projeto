﻿namespace Dispo.Domain.Enums
{
    public enum eMovementType
    {
        Input,
        Output,
        Transition
    }
}