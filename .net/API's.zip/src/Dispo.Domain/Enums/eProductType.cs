﻿namespace Dispo.Domain.Enums
{
    public enum eProductType
    {
        Food = 0,
        Comida = 0,

        Clothes = 1,
        Roupas = 1,

        Eletronics = 2,
        Eletronicos = 2,

        Books = 3,
        Livros = 3,

        Others
    }
}