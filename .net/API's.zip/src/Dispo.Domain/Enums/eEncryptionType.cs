﻿namespace Dispo.Domain.Enums
{
    public enum eEncryptionType
    {
        Email = 1,
        Password = 2,
    }
}