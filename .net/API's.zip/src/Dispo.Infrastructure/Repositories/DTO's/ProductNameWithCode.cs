﻿namespace Dispo.Infrastructure.Repositories.DTO_s
{
    public class ProductNameWithCode
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}