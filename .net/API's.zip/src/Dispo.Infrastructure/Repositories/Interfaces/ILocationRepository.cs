﻿namespace Dispo.Infrastructure.Repositories.Interfaces
{
    public interface ILocationRepository
    {
    }
}