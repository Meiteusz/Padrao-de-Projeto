﻿namespace Dispo.Infrastructure.DTOs
{
    public class ProviderDto
    {
        public string Name { get; set; }
        public string Cnpj { get; set; }
    }
}